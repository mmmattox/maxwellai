# LISTING.md — Storefront copy ($24)

Use or adapt on Gumroad, Lemon Squeezy, Stripe Payment Link description, etc.

---

## Product name (Stripe / storefront)

**MaxwellAI Agent Ops Drop-In Pack**

## Short description (≈ 160 chars)

Operating scaffold for solo AI agent shops: Cursor rules + Claude skills, ownership handoffs, never-invent-numbers, receive-only money. $24 ZIP.

## Long description

**Run specialist AI agents like a tiny company — without the fake metrics.**

Agent Ops Drop-In Pack is a static ZIP from MaxwellAI for builders who use Cursor and/or Claude Code as their workforce. It is not a “500 prompts” dump.

**You get:**

- 5-minute install for Cursor and Claude Code
- AGENTS.md — solo bot-shop operating contract (roles, handoffs, definition of done)
- CLAUDE.md — Claude Code project instructions
- Four Cursor rules: one-owner-per-output, never-invent-numbers (BLIND), receive-only-money, zip-fulfillment-qa
- Four skills: nightly brief, SKU scorecard, listing copy, distribution post drafts
- Honest limits — no invented user counts, no outbound sales automation

**Who it’s for:** Solo operators shipping digital products with AI agents.

**Who it’s not for:** Teams needing full company OS, CRM, or billing automation — that’s Bot Company OS ($29).

**Fulfillment:** Instant ZIP download. No account required beyond checkout.

**Price:** $24

---

## Bullets (storefront)

- Drop into any repo; Cursor rules load automatically
- Claude Code reads CLAUDE.md + skills out of the box
- Hard rule: agents never invent revenue or user counts
- Hard rule: money is receive-only (no agent-made payment links)
- Soft upgrade path to Bot Company OS when you want the full system

## FAQ (optional)

**Is this Bot Company OS?**  
No. This is the cheaper wedge pack. BCOS is the full OS at $29.

**Do you create my Stripe products?**  
No. You own payments. The pack teaches agents not to invent links or sales.

**Can I resell the pack?**  
Personal / client project use is fine. Do not rebrand and resell the pack as your own product.
