# MANIFEST — Agent Ops Drop-In Pack

MaxwellAI · $24 · All paths relative to pack root

## Root

| File | Purpose |
|------|---------|
| START-HERE.md | What you get / who for / who not / limits |
| README.md | 5-minute install (Cursor + Claude Code) |
| AGENTS.md | Solo bot-shop operating scaffold |
| CLAUDE.md | Claude Code project instructions |
| PRODUCT.md | Internal product facts |
| LISTING.md | Storefront copy |
| UPSSELL.md | Soft upsell to Bot Company OS $29 |
| MANIFEST.md | This file list |

## `.cursor/rules/`

| File | Purpose |
|------|---------|
| one-owner-per-output.mdc | Single owner + HANDOFF |
| never-invent-numbers.mdc | BLIND metrics policy |
| receive-only-money.mdc | No agent payment links / charges |
| zip-fulfillment-qa.mdc | Unzip + MANIFEST verification |

## `skills/`

| Path | Purpose |
|------|---------|
| nightly-brief/SKILL.md | Session ops brief |
| sku-scorecard/SKILL.md | Pre-build SKU scoring |
| listing-copy/SKILL.md | Storefront copy workflow |
| distribution-posts/SKILL.md | Draft-only distribution posts |

## Counts

- Root markdown: 8
- Cursor rules: 4
- Skills: 4
- **Total files (tracked above): 16**
