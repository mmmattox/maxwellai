# Skill: distribution-posts

## When to use

Need draft posts or newsletter blurbs to announce a SKU. **Human publishes** — agent only drafts.

## Inputs

- Product name, price, one-liner, buy URL **only if human or UPSSELL/PRODUCT already provided it**
- Channel list (default: X/Twitter, LinkedIn, short newsletter)

## Steps

1. Create `distribution/` if needed.
2. Write `distribution/<slug>-drafts.md`:

```markdown
# Distribution drafts — <product> — YYYY-MM-DD

Status: DRAFT ONLY — human sends. Agent did not post.

## X / Twitter (≤280 chars each)
1. ...
2. ...
3. ...

## LinkedIn (short)
...

## Newsletter blurb
...

## Do not claim
- Invented social proof
- “Just hit $X MRR”
- That the agent published these

## CTA
- Buy URL: (paste human-provided only) or “link TBD — human adds”
```

3. Tone: specific, operator-to-operator, no hustle-bro scarcity.
4. Mention receive-only / ZIP fulfillment if it differentiates.
5. Optional soft upsell line to Bot Company OS only if promoting the Drop-In Pack wedge story — use official URL from UPSSELL.md.

## Output

- `distribution/<slug>-drafts.md`
- Reminder in chat: “Drafts only — you post.”

## Anti-patterns

- Posting via APIs or browser as the human
- Fake engagement screenshots
- “Thread going viral” predictions stated as fact
- Multiple CTAs with invented coupon codes
