# Skill: listing-copy

## When to use

You need storefront title, short blurb, long description, and bullets for a digital product. Human pastes into Stripe/Gumroad/etc.

## Inputs

- PRODUCT.md or equivalent (name, price, includes, limits)
- Honest constraints from AGENTS.md (no fake metrics)

## Steps

1. Read product facts from disk — do not embellish with user counts.
2. Draft or update `LISTING.md` (or `listings/<slug>.md`) with:

```markdown
# Listing — <Product name>

## Product name
...

## Short description (≤160 chars)
...

## Long description
...

## Bullets
- ...

## Price
$NN

## FAQ
...
```

3. Include **who it’s for** and **who it’s not for**.
4. Include **honest limits** (what the ZIP does not do).
5. If an upsell exists (e.g. Bot Company OS), one soft sentence + real URL from UPSSELL.md only.
6. End with paste-ready **Stripe product name** and **description** suggestion — remind human to create the link (receive-only).

## Output

- Updated listing file
- Chat: name + short description + “create Payment Link yourself”

## Anti-patterns

- “Join 10,000 makers”
- Fake before/after revenue
- Agent-generated checkout URLs
- Claiming the product emails customers automatically if it doesn’t
