# Skill: sku-scorecard

## When to use

Before building a new digital product / ZIP / template. Score the idea so you don’t ship filler.

## Inputs

- Working title
- Price (human-set or proposed)
- One-sentence promise
- Fulfillment type (static ZIP default)

## Steps

1. Create `scorecards/` if needed.
2. Write `scorecards/<slug>.md` with:

```markdown
# SKU scorecard — <title>

| Dimension | Score 1–5 | Notes |
|-----------|-----------|-------|
| Clear buyer | | Who pays? Solo / team? |
| Wedge clarity | | Cheaper or narrower than what? |
| Fulfillment fit | | Static ZIP / docs / rules? |
| Agent-operable | | Can agents build 80%+ without human craft art? |
| Upsell path | | Natural next SKU? |
| Honesty risk | | Temptation to fake metrics? |

**Total ( /30 ):** N

## Go / No-go

- **Go** if total ≥ 20 and honesty risk ≤ 2 mitigation needed
- **Maybe** if 15–19 — shrink scope
- **No-go** if < 15 or fulfillment isn’t files-on-disk

## Blind fields
- Market size: BLIND
- Expected conversion: BLIND

## Recommended MVP contents
- (bullet list of real files)

## Price check
- Listed price: $...
- Must not invent discounts or “$Xk value”
```

3. Recommend **build**, **shrink**, or **drop** in one line.
4. If **build**, sketch MANIFEST filenames only — don’t invent sales channels as “already live.”

## Output

- `scorecards/<slug>.md`
- One-line verdict in chat

## Anti-patterns

- Scoring “viral potential” as a fact
- Assuming Stripe/Gumroad conversion rates
- Greenlighting “500 prompts” dumps (low wedge clarity)
