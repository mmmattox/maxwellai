# Agent Ops Drop-In Pack — 5-Minute Install

MaxwellAI · Works with **Cursor** and **Claude Code**

## What this is

A ready-to-drop operating layer for a solo bot shop: agent ownership rules, Cursor `.mdc` rules, Claude Code instructions, and four reusable skills. Copy into your project root and start working.

---

## Cursor (≈ 3 minutes)

1. Unzip this pack somewhere temporary.
2. Copy into your project root (merge, don’t overwrite your own files blindly):

   ```bash
   # From your project root
   cp /path/to/agent-ops-drop-in/AGENTS.md .
   cp /path/to/agent-ops-drop-in/CLAUDE.md .   # optional; useful if you also use Claude Code
   mkdir -p .cursor/rules
   cp /path/to/agent-ops-drop-in/.cursor/rules/*.mdc .cursor/rules/
   mkdir -p skills
   cp -R /path/to/agent-ops-drop-in/skills/* skills/
   ```

3. Open the project in Cursor. Rules under `.cursor/rules/*.mdc` load automatically.
4. Skim `AGENTS.md` once — that is the operating contract for every agent turn.
5. Optional: pin `AGENTS.md` or `START-HERE.md` in chat context for the first few sessions.

**Verify:** Ask Cursor “What ownership rule applies to outputs?” — it should cite one-owner-per-output / AGENTS.md.

---

## Claude Code (≈ 2 minutes)

1. Unzip the pack.
2. Copy into the repo Claude Code will use:

   ```bash
   cp /path/to/agent-ops-drop-in/CLAUDE.md .
   cp /path/to/agent-ops-drop-in/AGENTS.md .
   mkdir -p skills
   cp -R /path/to/agent-ops-drop-in/skills/* skills/
   ```

3. Claude Code reads `CLAUDE.md` (and often `AGENTS.md`) as project instructions. Skills live under `skills/<name>/SKILL.md` — invoke by name or paste the skill body when you need that workflow.
4. Start a session and say: “Follow CLAUDE.md and AGENTS.md. Run the nightly-brief skill for today.”

**Verify:** Ask “Can you invent a revenue number for the listing?” — it should refuse and cite the blind / never-invent-numbers rule.

---

## Both (recommended)

If you use Cursor *and* Claude Code on the same repo:

| File | Role |
|------|------|
| `AGENTS.md` | Shared operating scaffold (both tools) |
| `CLAUDE.md` | Claude Code–specific project instructions |
| `.cursor/rules/*.mdc` | Cursor-only persistent rules |
| `skills/*/SKILL.md` | Workflows either tool can follow |

Keep money receive-only. Do not ask agents to create Stripe links, send invoices, or claim sales.

---

## After install

1. Read **START-HERE.md** (what you got / limits).
2. Customize product names in skills if your SKUs differ.
3. When you’re ready for the full OS (SKU pipeline, more skills, deeper ops), see **UPSSELL.md**.

---

## Support

This is a static ZIP product. No chat support seat is included. Fix gaps yourself or upgrade to Bot Company OS for the fuller system.
