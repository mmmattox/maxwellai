# PRODUCT.md — Agent Ops Drop-In Pack

| Field | Value |
|-------|--------|
| **Brand** | MaxwellAI |
| **Product name** | Agent Ops Drop-In Pack |
| **Price** | $24 |
| **Format** | Static ZIP (docs + Cursor rules + Claude skills) |
| **Fulfillment** | Download ZIP (host on GitHub Pages or any static URL) |
| **Related SKU** | Bot Company OS — $29 — full OS upsell |

## One-liner

Drop-in agent operating pack for solo builders running Cursor + Claude Code like a tiny company — ownership rules, blind metrics, receive-only money, and four ship-ready skills.

## Positioning

**Wedge under Bot Company OS.** Buyers who aren’t ready for the full OS get a tight scaffold: how agents hand off work, how they refuse fake numbers, and how they ship ZIPs without inventing sales. Soft path up to BCOS when they want the whole system.

## Includes

- START-HERE, README (5-min Cursor + Claude Code install)
- AGENTS.md operating scaffold
- CLAUDE.md for Claude Code
- 4× `.cursor/rules/*.mdc` (ownership, BLIND numbers, receive-only money, ZIP QA)
- 4× skills: nightly-brief, sku-scorecard, listing-copy, distribution-posts
- Storefront copy (this file + LISTING.md)
- UPSSELL.md → Bot Company OS

## Does not include

- Stripe product creation or live payment links (human-owned)
- Hosting, email delivery, or support seat
- Fake metrics, prompt packs, or “AI agency” course content
- The full Bot Company OS feature set

## Buyer promise

Install in five minutes. Agents stop inventing revenue and fighting over the same file. You still own pricing, Stripe, and what gets published.
