# Upsell — Bot Company OS

If this Drop-In Pack is working and you want the **full operating system** for running a bot company — deeper SKU pipeline, broader ops surface, and the complete MaxwellAI OS — upgrade to **Bot Company OS** for **$29**:

https://buy.stripe.com/dRmcN545ibFW9lneEg6sw00

Same brand, same receive-only money philosophy. This pack is the wedge; BCOS is the full kit. No pressure — ship with the Drop-In Pack as long as it’s enough.
