# Agent Ops Drop-In Pack — Start Here

**MaxwellAI · $24 · Static ZIP · No account required**

## What you get

A drop-in operating scaffold for running specialist AI agents like a tiny company — not a prompt dump. You get:

- **AGENTS.md** — ownership, handoffs, and receive-only money rules for a solo bot shop
- **CLAUDE.md** — Claude Code project instructions ready to paste or copy in
- **README.md** — 5-minute install for Cursor and Claude Code
- **`.cursor/rules/`** — four Cursor rules (one-owner outputs, blind numbers, receive-only money, ZIP fulfillment QA)
- **`skills/`** — four Claude-style skills: nightly brief, SKU scorecard, listing copy, distribution posts
- **PRODUCT.md / LISTING.md** — storefront copy you can reuse or adapt
- **UPSSELL.md** — optional path to the full Bot Company OS

## Who it’s for

- Solo builders running Cursor and/or Claude Code as their “staff”
- People shipping digital products (ZIPs, docs, templates) with AI agents as the workforce
- Operators who want hard rules: one owner per output, never invent metrics, money is receive-only

## Who it’s not for

- Teams that need multi-seat collaboration, billing automation, or CRM
- Anyone looking for “500 ChatGPT prompts” or vibe-marketing filler
- People who want invented growth numbers, fake social proof, or outbound sales scripts
- Full company OS seekers — that’s [Bot Company OS](https://buy.stripe.com/dRmcN545ibFW9lneEg6sw00) ($29)

## Honest limits

This pack is a **scaffold**, not a finished business. It does not:

- Create Stripe products or payment links for you
- Send emails, posts, or messages on your behalf
- Track revenue, users, or conversions
- Replace judgment about what to sell

You still decide the product. The pack keeps agents from inventing numbers, claiming sales they didn’t make, or stepping on each other’s outputs.

## Next step

Open **README.md** and do the 5-minute install.
