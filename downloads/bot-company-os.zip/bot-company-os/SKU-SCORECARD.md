# SKU scorecard
Use this before you build. A SKU that cannot fill every row is not a SKU.

**Date:**
**Candidate name:**
**One-line job:**

## Demand (from live pages only)
| Analog product | URL | Price on page | Users / ratings on page | Notes |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |

If a number is not on the page, write **BLIND**. Third-party blogs are not user counts.

## No-talk test
- Fulfillment is a file or a button. No onboarding call. Yes / No
- Checkout + tax + receipt + cancel handled by a processor. Yes / No
- Failure mode is local and loud, not “please send me your file.” Yes / No

If any No, kill or cut scope.

## First-dollar without an audience
- People already type a query on a store that has search. Write the queries:
- Free tier or preview that installs / downloads without a pitch deck:
- Pay reason in one sentence (privacy, cap, speed, a hole the analog leaves):

## Build
- MVP in the time budget? What’s in / never:
- Cash to list (store fee, domain). Must fit the ceiling:
- Support bombs you will **not** ship (the features that create “doesn’t work” mail):

## Kill risks
Crowded / policy / support / TOS / race-to-bottom. Name the one most likely to kill it.

## Verdict
SHIP / HOLD / KILL
One paragraph. No second SKU in the same verdict.
