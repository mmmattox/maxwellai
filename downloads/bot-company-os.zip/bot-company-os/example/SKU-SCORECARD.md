# SKU scorecard (example, fictional numbers marked)
**Date:** 2026-08-30
**Candidate:** InkKeep
**One-line job:** Highlight text on any page, keep it on-device, export Markdown.

## Demand
| Analog | URL shape | Price on page | Users / ratings | Notes |
|---|---|---|---|---|
| Cloud highlighter A | CWS listing | $3.99/mo annual on official pricing | 200,000 users, 4.0 / 2.8K (on CWS page) | Last updated 2024 — stale. Recent review quality is a third-party warning, not a store number. |
| Social highlighter B | CWS listing | $15/mo or $12.50/mo annual (FAQ) | 500,000 users, 4.5 / 981 | Account + AI summaries. Different product. |

Replace these with live fetches when you run a real scout. The row shape is the point.

## No-talk test
- Button: select → color → export. Yes
- Processor handles checkout. Yes (when armed)
- Failures are “this page blocked the overlay,” not “email us your highlights.” Yes

## First-dollar
Queries: `web highlighter`, `highlight to markdown`. Pay reason: your notes never go to their cloud.

## Build
MVP: content script + IndexedDB + .md export. Never: PDF, login, AI.

## Kill risks
Crowded aisle. Win only as the anti-account tool. PDF is how the analog earned its recent 1-stars.

## Verdict
SHIP as v1 local-only. HOLD PDF forever unless Offer rewrites the sheet.
