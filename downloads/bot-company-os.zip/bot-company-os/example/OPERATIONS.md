# OPERATIONS.md (example, fictional)
Status: EXAMPLE. InkKeep is not listed. Not charging.

## Mission
A no-talk product factory. One utility on a store that already has buyers.

## Facts (example)
- Income to add: first dollar in 30 days, then a repeatable SKU.
- Starting assets: none. No list.
- Skills: technical. Can ship a browser extension.
- Time: 2–3 hours/night on a phone, talking to CoS.
- Cash ceiling: a few hundred dollars. Store fee is the only planned spend.
- Risk: no legal gray. No employer data in the product.
- Enough: 30d = listed. 90d = first dollars, support ~zero.

## Money path (example lock)
- **Surface:** Chrome Web Store search (`highlighter`, `web highlight markdown`).
- **Billing:** off-store merchant of record. CWS payments are dead. Not armed.
- **Fulfillment:** the extension. Free: unlimited local highlights, export last 20. Paid: unlimited export + tags + search. $19 one-time or $3/mo.
- **Never in v1:** PDF highlighting, accounts, AI summaries, classroom seats.
- **Founder residue:** KYC, $5 store fee, tap-to-publish.

## Why this SKU (scorecard summary)
Two Featured analogs exist with paid plans. The stale analog’s recent reviews cluster on login and vanished highlights — cloud sync is the support bomb. InkKeep only works if it is the opposite: local store, no login, export is the product.

## Kill
30 days cannot list, or 90 days live with zero dollars. Scope creep into PDF or AI chat is an immediate kill.
