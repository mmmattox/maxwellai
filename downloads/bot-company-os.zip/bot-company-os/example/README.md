# Example company: InkKeep
Fictional. Not a live product. Copied here so you can see a filled OS, not a blank sermon.

**SKU:** InkKeep — a local-first web highlighter that exports Markdown. No account. No cloud folder.
**Why this example:** it is a button (select → save → export), people already shop the aisle, and the analog’s reviews complain about login loops — which is the hole.

Do not list InkKeep. Do not copy its name to a store. Steal the *shape*.
