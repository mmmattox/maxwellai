# Bot Company OS — $29
Storefront copy. Instant zip. No account after purchase.

**One line:** Run a night shift of AI agents. One job each. You only tap the gates.

**In the zip**
- Operations, roster, nightly four-line brief, offer one-pager, reviewer checklist
- SKU scorecard (markdown + local HTML that exports .md — nothing uploaded)
- Worked fictional example (InkKeep) so you copy the shape, not a fake SKU

**Not in the zip:** customers, ads, a promise of revenue, a Slack, updates.

**Buy this if** you already have Cursor / Claude Code / ChatGPT / Grok and two hours at night, and the agents keep thrashing, double-owning work, or inventing numbers.

**Do not buy this if** you want the agent to DM buyers, run ads, or handle payouts unsupervised.

Setup is 15 minutes: paste Operations + one hire block into the agent’s job. First night: one specialist. First week: one SKU.
