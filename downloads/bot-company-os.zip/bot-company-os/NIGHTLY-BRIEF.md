# Nightly brief
Date:
On tonight: yes / no

1. **Moved** (one sentence, shipped or decided):
2. **Almost shipped** (artifact name + what’s left):
3. **Decision** (one yes/no/edit — or “none”):
4. **Blocked** (named owner + the missing tap):

Rules: four lines. No appendix. If you need a fifth line, CoS failed to simplify. Cash figures only if verified. Otherwise BLIND.
