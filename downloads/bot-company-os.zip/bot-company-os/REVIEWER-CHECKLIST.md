# Reviewer checklist
Score an external artifact. PASS or FAIL. Do not rewrite. One owner, one rule, one required fix on a FAIL.

Date:
Artifact:
Owner:

1. **Legal / store:** paid features disclosed before install or purchase. Not branded simply “Free” if a cap gates daily use. Yes / No / n/a
2. **BLIND:** no invented users, ratings, revenue, refund window, or legal entity. Yes / No
3. **Employer wall:** no employer data, customers, hours, or work software. Yes / No
4. **SKU wall:** one SKU. No second product in this listing. Yes / No
5. **No-talk:** no “contact us,” founder email, or hop-on-a-call as the product. Yes / No
6. **Privacy match:** claims match the one-pager. No compliance badges you do not have. Yes / No
7. **Paywall match:** price, cap, and processor match the one-pager. Yes / No
8. **Screenshots:** real product, required pixel sizes, no fake UI. Yes / No / wait
9. **Off-SKU / hype:** no “#1,” “trusted by N,” or analog user counts as ours. Yes / No
10. **Publish gate:** this is a draft. Founder is the only publisher. Yes / No

Verdict: PASS / FAIL
If FAIL: owner, rule number, required fix (one sentence).
