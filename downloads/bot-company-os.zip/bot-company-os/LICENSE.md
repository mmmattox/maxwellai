# License
Personal use. You may use these files for your own agents and companies, including commercial work you ship.

You may not resell, relic, or republish this pack (or a thin rewrite) as a competing template.

No warranty. No updates promised. Not legal, tax, or investment advice.
