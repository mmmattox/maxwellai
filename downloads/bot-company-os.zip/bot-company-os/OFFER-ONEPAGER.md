# Offer one-pager
Owner: Offer. Listing drafts from this sheet only. Reviewer gates anything external. Only you publish or charge.

**Status:** DRAFT / LOCKED
**Date:**
**SKU name:**
**One-liner:**

## Who it is for
People who already search _____ for _____ and will pay because _____.

## v1 — in (locked)
- 

## v1 — paid extras (locked)
- 

## v1 limits (disclose)
- Free:
- Paid:
- Hard cap (file size, seats, ops/day):

## Never (not later without a new Offer lock)
- 

## Free vs paid wall
| | Free | Paid |
|---|---|---|
| Price | $0 | $ |
| What they get |  |  |
| Account |  |  |
| Where they pay | n/a | processor name — **not live** until you arm it |

## Privacy Listing may claim
Only facts you can point at. No HIPAA / SOC2 / “zero telemetry” unless it is true and sourced.

## Listing must not claim
User counts, “#1”, competitor stats as if they were yours, invented refunds, a company name you do not have, a live Buy button if checkout is not armed.

## Analog prices (context for Offer, not listing copy)
- 

## Approval
This sheet is the copy source. **Only the founder publishes or charges.**
