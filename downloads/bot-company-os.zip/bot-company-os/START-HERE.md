# Bot Company OS
A drop-in operating system for running a small company of AI agents that make money while you only tap the gates.

**Who this is for:** one person with 2–3 hours at night, no audience, and a coding agent (Cursor, Claude Code, ChatGPT, Grok, or similar). You are the CEO. The agents do production. You publish, pay, and kill.

**Who this is not for:** people who want the agent to tweet, DM strangers, or “just handle PayPal.” Those are gates. Leave them as gates.

**What you get**
- `OPERATIONS.md` — mission, money path, constraints, kill rules, approval gates
- `ROSTER.md` — how to hire specialists so two bots never own the same output
- `NIGHTLY-BRIEF.md` — the only thing you read on your phone
- `SKU-SCORECARD.md` — pick one no-talk product people already pay for
- `example/` — a fully filled fictional company so you can copy the shape, not the SKU
- `PRODUCT.md` — storefront one-pager
- `sku-scorecard.html` — local form that exports the scorecard as markdown (nothing is uploaded)

**15-minute setup**
1. Copy `OPERATIONS.md` and `ROSTER.md` into a folder your agents can read.
2. Fill the **Facts** block in Operations. Do not invent a number. Write BLIND.
3. Hire **one** specialist tonight (Offer, or Scout if you do not have a SKU). Paste their block as that agent’s job description.
4. Tomorrow night, fill `NIGHTLY-BRIEF.md` in four lines. If you need more than one decision, you have not simplified yet.
5. Nothing leaves the building (post, listing, charge, spend) until you tap it.

**Price of this pack:** whatever you paid. Lifetime of the files. No updates promised. No call. No Slack.

**Honest limit:** this is an operating system, not distribution. Getting the first stranger to the checkout is still on you (or on a store that already has search). The scorecard exists so you pick a SKU that can be found without a following.
