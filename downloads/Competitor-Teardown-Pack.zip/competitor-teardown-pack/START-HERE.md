# Start here — Competitor Teardown Pack

Thanks for buying. Here’s what you have and how to use it.

## What you get (instant)

1. **`sample/`** — a complete example teardown (`BRIEF.md` + `competitors.csv`) for the on-device PDF tools niche. Read this first so you know the shape and quality bar.
2. **`templates/`** — blank `BRIEF.template.md` and `competitors.template.csv` you can fill yourself.
3. **`docs/`** — buyer brief fields and fulfillment notes for the optional custom job.

## Optional custom teardown (24h)

Included with this purchase: one custom teardown for **your** niche.

1. Open `docs/BUYER_BRIEF.md`.
2. Email **mmattox10@gmail.com** with:
   - Niche / product category (one sentence)
   - Up to 5 competitor URLs or names (optional)
   - Decision you need help with (wedge, pricing, copy, build/no-build)
   - Deadline if tighter than 24h (we may decline)
3. We deliver `competitors.csv` + ≤2-page `BRIEF.md` within **24 hours** of a complete brief.

**Rules we follow:** public pages only; anything not on-page is marked **BLIND**; no invented sales or ratings; no calls.

## Support

mmattox10@gmail.com — reply within 2 business days for pack questions.
