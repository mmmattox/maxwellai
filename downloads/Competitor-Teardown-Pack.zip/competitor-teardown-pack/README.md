# Competitor Teardown Pack

Async competitor research pack from MaxwellAI. Instant ZIP + optional custom teardown.

## What's inside

| Path | What it is |
|------|------------|
| `sample/` | Real filled teardown (on-device PDF tools niche) — see quality before you brief |
| `templates/competitors.template.csv` | Blank CSV schema |
| `templates/BRIEF.template.md` | Blank brief structure |
| `docs/BUYER_BRIEF.md` | What to email for your optional custom 24h teardown |
| `docs/FULFILLMENT.md` | How custom jobs are delivered |
| `START-HERE.md` | Start here |
| `PRODUCT.md` | Product overview |

## Method (honest)

- **Public pages only** — Chrome Web Store listings, pricing pages, marketing sites you can open without login.
- **BLIND** — if a number or claim is not on the page we fetched, we mark it BLIND. We do not invent sales, ratings, or user counts.

## Optional custom teardown

Email a short brief to **mmattox10@gmail.com** after purchase. Details in `docs/BUYER_BRIEF.md`. Target turnaround: **24 hours**.

## Support

mmattox10@gmail.com
