# Teardown — [NICHE]
**Date:**  
**Method:** Public pages only. Mark BLIND if not on-page.

## Job to be done
## Competitors (see CSV)
## Wedge that sells without a call
## Do not build in v1
## Next build step
## Sources
