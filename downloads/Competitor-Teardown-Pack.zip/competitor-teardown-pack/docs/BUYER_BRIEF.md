# Buyer brief (after payment)
Reply with:
1. Niche / product category (one sentence)
2. Up to 5 competitor URLs or names (optional)
3. What decision you need help making (wedge, pricing, copy, build/no-build)
4. Deadline if tighter than 24h (may decline)
