# Optional custom teardown — how it works

After you buy the pack, you can request one custom teardown (included with purchase):

1. Email your brief to **mmattox10@gmail.com** using the fields in `docs/BUYER_BRIEF.md`.
2. We research **public pages only**. Anything not on-page is marked **BLIND**.
3. You receive `competitors.csv` + a ≤2-page `BRIEF.md` (wedge, copy angles, do-not-build) within **24 hours** of a complete brief (timezone: ET).
4. One revision pass if your ask stays within the original scope; otherwise we close the job.
5. Tighter-than-24h deadlines may be declined.

No calls. No private/login-walled scraping. No invented metrics.
