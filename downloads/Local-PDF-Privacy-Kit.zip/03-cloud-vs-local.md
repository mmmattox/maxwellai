# Cloud vs local — quick decision

| Situation | Prefer |
| --- | --- |
| Tax / medical / lease / passport scan | **Local only** |
| Public brochure, already online | Cloud OK |
| Work doc under employer DLP policy | Follow employer — usually **local / approved tools** |
| One-off “just make it smaller” meme PDF | Cloud OK |

If you hesitate for one second, keep it local.
