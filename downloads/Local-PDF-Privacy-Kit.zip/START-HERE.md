# Local PDF Privacy Kit — $19

**What this is:** A no-upload PDF ops kit for people who refuse to send tax/lease/medical PDFs to cloud tools (Smallpdf, iLovePDF, etc.).

**What you get**
1. `01-privacy-onepager.md` — one-page “files stay on your device” brief
2. `02-ops-checklist.md` — merge / split / compress / rotate checklist (tool-agnostic)
3. `03-cloud-vs-local.md` — decision sheet when cloud is OK vs not
4. `04-chrome-local-tools.md` — how to run PDF work in Chrome without uploading
5. `05-buyer-receipt.md` — what your Stripe receipt means + refund note

**Fulfillment:** Instant ZIP download after Stripe payment. No call. No DM. No account.

**Not included:** A Chrome Web Store listing (optional later). This kit is usable today without CWS.
