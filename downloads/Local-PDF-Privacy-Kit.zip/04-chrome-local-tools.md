# Chrome-local PDF work (no upload)

Options that keep bytes on-device:
1. A **local** Chrome extension (side panel / MV3) that never posts the PDF to a server
2. Desktop tools (Preview, Acrobat, `qpdf`, etc.)
3. Print-to-PDF from a local viewer

**Avoid:** sites whose first step is “Upload your PDF.”

When DeskPDF (or similar) is sideloaded: Chrome → `chrome://extensions` → Developer mode → Load unpacked → select the extension folder with `manifest.json`.
