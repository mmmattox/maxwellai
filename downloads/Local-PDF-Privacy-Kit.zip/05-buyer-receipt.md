# After you buy

1. Stripe emails your receipt.
2. Download this ZIP from the fulfillment URL in the product page / receipt note.
3. No account. No Zoom. No “email us to cancel.”

**Refunds (proposed policy):** 14 days via Stripe customer portal / receipt. Monthly products (if any) cancel in the portal.
