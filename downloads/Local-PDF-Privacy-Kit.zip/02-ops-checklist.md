# Local PDF ops checklist

## Before you start
- [ ] File is on disk (not only in Gmail preview)
- [ ] You are OK with a **local** tool (browser extension, desktop app, or CLI) — not an upload site
- [ ] Sensitive? Prefer airplane mode / offline after the file is local

## Merge
- [ ] Order pages/files intentionally
- [ ] Spot-check first/last page of output
- [ ] Delete temp copies

## Split / extract
- [ ] Write the page range down (`1-2, 5`)
- [ ] Confirm page count of output
- [ ] Shred intermediate exports if sensitive

## Compress
- [ ] Expect **lossy** options to hurt text select / sharpness
- [ ] Never promise “90% smaller”
- [ ] Keep an original

## Rotate
- [ ] Note 90 / 180 / 270 before you run
- [ ] Check landscape pages didn’t flip wrong

## Done
- [ ] Output saved where you meant
- [ ] Originals archived or deleted on purpose
