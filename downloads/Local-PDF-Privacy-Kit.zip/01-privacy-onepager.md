# Keep PDFs on your device

Cloud PDF sites ask you to **upload** the file. That is the wrong default for tax returns, leases, medical forms, and HR packets.

**Local rule:** pick the file → process on this computer → save the result. The PDF bytes never go to a random SaaS.

Use this kit’s checklists before you merge, split, compress, or rotate anything sensitive.
