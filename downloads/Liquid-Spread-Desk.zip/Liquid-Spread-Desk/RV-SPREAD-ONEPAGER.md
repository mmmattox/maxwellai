# Liquid Spread Desk — RV / pair one-pager

## Core rule
**Activity ≠ EV.** If you can’t write the entry gap and the exit rule before the trade, you don’t have a trade.

## Equity pairs (cash session)
1. Cousin pair only (examples: KO/PEP, XOM/CVX, SPY/QQQ).
2. ~60 trading-day closes → ratio = A/B.
3. z = (ratio − mean) / sd.
4. Enter if |z| ≥ ~1.3: long cheap / short rich, dollar-neutral.
5. Soft cut if |z| expands past ~2.5 against you.
6. Marks = timestamped live quotes. Never invent fills.
7. Log every field in `spread_log_template.csv`.

## Crypto RV (24h)
1. Day return = (mark − open) / open for BTC and alts.
2. If alt day-ret lags BTC by ≥ ~0.8–1.0% and liquidity is fine: long alt / short BTC, small dollar-neutral size.
3. Remake on schedule, not every tick.
4. Flatten if lag widens hard without mean-revert, or thesis breaks.
5. Paper until real rails + risk rules say otherwise.

## Position sizing (desk default)
- Per-leg notional ≤ ~30% of working book at entry for a single pair cluster.
- Two sleeves max until one proves it can pay for attention.

## Kill criteria for a setup
- Gap never existed (you forced a trade).
- Correlation broke (pair stopped being cousins).
- You’re remaking marks to feel busy.

## What this pack is not
Not signals. Not financial advice. Not a promise of returns.
