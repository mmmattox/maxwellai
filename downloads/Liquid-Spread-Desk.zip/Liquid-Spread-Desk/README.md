# Liquid Spread Desk
1. `RV-SPREAD-ONEPAGER.md` — process
2. `checklist.md` — gates
3. `spread_log_template.csv` — log
4. `spread_log_SAMPLE.csv` — format only
5. `WORKED-EXAMPLE.md` — illustrative paper-desk math
6. `FAQ.md`
7. `LISTING.md` — store copy draft
