# Liquid Spread Desk — $19
Pair & crypto RV checklist pack. Process over vibes. Activity ≠ EV.

**Includes:** one-pager, checklist, CSV log template + sample, worked example, FAQ.

**Buy:** Stripe **PAUSED** (Pure R&D). Payment Link not live. Spec ready in `PAYMENT-LINK-SPEC.md`.

Instant digital download when rail opens. No calls.
