# Liquid Spread Desk — micro product
**Price:** $19 one-time (draft, list-ready copy in LISTING.md)
**One-liner:** A practical desk pack to run liquid equity-pair and crypto RV checks without fooling yourself.

## Includes (this folder)
1. `RV-SPREAD-ONEPAGER.md`
2. `checklist.md`
3. `spread_log_template.csv`
4. `spread_log_SAMPLE.csv` (illustrative paper-desk rows)
5. `LISTING.md` (Gumroad draft)
6. `WORKED-EXAMPLE.md`
7. `FAQ.md`

## Buyer
Solo traders / desk assistants watching liquid pairs / BTC–alt RV who want process, not picks.

## Comps (list prices; volume BLIND)
- $19 Gumroad options journal pack: https://larkmade.gumroad.com/l/etiloc
- $25.99 swing journal spreadsheet: https://spreadsheetshub.com/products/swing-trading-journal

## Paper-score rule
- **No invented sales.**
- Artifact pack = this folder + ZIP.
- Unproven deal EV only if Money Machine accepts: expected sales × $19 × **0.30**.
- Conservative discussion assumption: 1–2 week-1 sales → haircut book **$5.70–$11.40** — **not auto-booked to NAV**.

## Status
LIST-READY DRAFT — not published. No revenue claimed. No Max asks required to finish artifacts.
