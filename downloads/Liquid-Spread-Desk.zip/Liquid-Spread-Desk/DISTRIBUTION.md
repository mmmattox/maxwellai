# Distribution plan — zero Max labor
Goal: inbound discovery without Max DMs/calls.

## Channels (agent-operable drafts only until rail)
1. **Store page copy** — `LISTING.md` / `SALES-PAGE.md` (done)
2. **SEO one-pager keywords** — “pair trading checklist”, “ETH BTC ratio worksheet”, “mean reversion log”
3. **Public free teaser** — optional 1-page excerpt from one-pager (not shipped live while Stripe paused)
4. **Cohort cross-link** — when Money Machine opens a catalog, Liquid Spread Desk is the Deal Flipper SKU

## Explicit non-channels
- Max cold outreach
- Max Discord/Reddit posting as labor
- Fake testimonials / invented users
