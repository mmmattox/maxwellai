# Fulfillment plan — zero Max labor
1. Buyer pays (when rail live) via Payment Link @ $19
2. Instant delivery of `Liquid-Spread-Desk.zip`
3. No onboarding calls; FAQ covers objections
4. Refunds: 30-day digital (draft policy in LISTING)
5. Until Stripe live: pack stays downloadable as R&D artifact only — **not sold**
