# FAQ

**Is this financial advice?** No. Process pack only.

**Do I get trade alerts?** No. You run the checks.

**Excel or Google Sheets?** CSV imports to both. Template is blank; sample shows format.

**Why $19?** Aligned with simple Gumroad checklist/journal packs publicly listed around $19–$26.

**Refunds?** Draft: 30-day Gumroad-style digital refund when listed.

**Will this make money?** Unknown. If you can’t state the gap and exit before entry, skip the trade.
