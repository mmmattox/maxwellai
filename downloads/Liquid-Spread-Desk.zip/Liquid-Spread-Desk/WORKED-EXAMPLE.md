# Worked example (illustrative paper desk — not a signal)

## Equity: KO/PEP on 2026-09-11 closes
- 60d ratio mean ≈ 0.6130, sd ≈ 0.0237
- Last ratio ≈ 0.6477 → **z ≈ +1.46**
- Rule: |z| ≥ 1.3 → fade rich KO vs PEP
- Paper action taken: SHORT 3 KO @ 88.265 / LONG 2 PEP @ 136.30
- Marks: Robinhood `last_trade_price` @ 2026-09-11T19:59:59Z

## Crypto: ETH vs BTC day-lag on 2026-09-13
- BTC day ret ≈ −0.11%, ETH ≈ −1.30% → lag ≈ −1.19pp
- Rule: alt lag ≤ −0.8pp → long alt / short BTC (small)
- Paper action: LONG ETH ~$300 / SHORT BTC ~$300 at mark_price
- Marks: Robinhood crypto `mark_price` @ 2026-09-13T11:11:24-04:00

## Lesson
The value is the **rule + timestamped log**, not the remake frequency.
