# Liquid Spread Desk — Stripe Payment Link spec
Status: READY TO CREATE after Stripe inbound auth. Do not invent a live URL.

## Product
- Name: Liquid Spread Desk
- Type: one-time digital download
- Amount: **$19.00 USD**
- Tax: off until Max has Stripe Tax registration (do not enable automatic_tax blindly)

## Payment Link settings (Dashboard or API)
- `line_items`: one price, unit_amount **1900**, currency **usd**, product name above
- `after_completion`: redirect or hosted confirmation — message: “Check your email for the download (Liquid-Spread-Desk.zip).”
- Collect billing address: optional
- Allow promotion codes: off (v1)
- Quantity adjust: off (fixed 1)
- Payment method: let Stripe dynamic methods (omit payment_method_types)

## Fulfillment (no Max labor)
1. Buyer pays via Payment Link
2. Stripe email receipt fires
3. Delivery options (pick one at go-live):
   - **A (fastest):** Payment Link “after payment” custom message includes a stable download URL (signed/storage) to `Liquid-Spread-Desk.zip`
   - **B:** Webhook `checkout.session.completed` → email ZIP link (needs automation after rail)
4. Until webhook exists: use **A** with a hosted file URL Max/agent places once

## Artifact paths
- ZIP: `/home/box/deal-flipper/Liquid-Spread-Desk.zip`
- Listing copy: `LISTING.md`
- Pack folder: `/home/box/deal-flipper/micro-asset/`

## Go-live checklist
- [ ] Stripe inbound connected / authenticated
- [ ] Create Payment Link @ $19
- [ ] Host ZIP at durable HTTPS URL (or attach to confirmation email)
- [ ] Paste Payment Link URL into `LIVE.md`
- [ ] Smoke-test $19 (or Stripe test mode first if available)
- [ ] Book verified cash only after payout/settlement rules Max sets — never invent sales

## Explicit non-goals
- No trading float
- No Max customer contact
- No invented Payment Link URL before auth
