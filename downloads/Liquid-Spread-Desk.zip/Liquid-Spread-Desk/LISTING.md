# Gumroad listing draft — Liquid Spread Desk
**Status:** DRAFT — not published. No Max ask in this file.

## Title
Liquid Spread Desk — Pair & Crypto RV Checklist Pack

## Price
$19 one-time

## Tagline
Run liquid equity-pair and crypto relative-value checks without confusing activity for edge.

## Description
Most “spread” notes are vibes. This pack is a tight desk process for liquid cousins only:

- Equity pairs (KO/PEP, XOM/CVX, SPY/QQQ-style): 60-day ratio z-score entry/exit rules
- Crypto RV (BTC vs ETH/SOL): day-lag relative mean-reversion with mark timestamps
- Hard rule: **activity ≠ EV** — remaking marks is not an edge

### You get
1. RV Spread One-Pager (process + anti-self-fooling rules)
2. Pre-trade / open / exit checklist
3. Blank `spread_log_template.csv`
4. Sample log rows from a real paper desk (illustrative)

### Who it’s for
Solo traders and desk assistants who already watch liquid names and want a repeatable RV checklist — not signals, not “guaranteed returns.”

### Who it’s not for
Penny-coin degen chats, options 0DTE, or anyone wanting picks instead of a process.

## Comps (public list prices; sold volume BLIND)
- Gumroad “Option Trader’s Journal” pack: **$19** — https://larkmade.gumroad.com/l/etiloc
- SpreadsheetsHub swing journal: sale **$25.99** (was $54.99) — https://spreadsheetshub.com/products/swing-trading-journal
- Other Gumroad journals: **$97** systems exist (different scope) — https://glenncove.gumroad.com/l/tradingjournal

Price wedge: **$19** aligns with simple journal/checklist packs.

## Refund
30-day digital refund (standard Gumroad) — draft policy until rails live.

## Fulfillment
Instant download ZIP. No calls. No Discord. No “hop on a call.”


## Deliverables table
| File | Purpose |
|------|---------|
| RV-SPREAD-ONEPAGER.md | Core process |
| checklist.md | Pre / open / exit |
| spread_log_template.csv | Blank log |
| spread_log_SAMPLE.csv | Format example |
| WORKED-EXAMPLE.md | Real paper-desk numbers (illustrative) |
| FAQ.md | Objections |

## Promise
You get a repeatable RV desk process. You do **not** get picks, alerts, or return guarantees.
