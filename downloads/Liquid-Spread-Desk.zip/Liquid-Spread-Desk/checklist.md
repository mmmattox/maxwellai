# Liquid Spread Desk — checklist

## Before entry
- [ ] Liquid cousins only
- [ ] Timestamped quotes saved (source + time)
- [ ] Metric computed (z or day-lag) with numbers written down
- [ ] |gap| clears threshold
- [ ] Dollar-neutral notionals set
- [ ] Soft stop + hard book stop written
- [ ] Logged in CSV before fill

## While open
- [ ] Remake on schedule (not compulsive)
- [ ] Thesis still true? (still cousins / still RV)
- [ ] Soft stop hit?
- [ ] Are you confusing activity with EV?

## Exit
- [ ] Target (mean / lag closed) or stop
- [ ] Exit mark timestamped
- [ ] P&L logged with sources
- [ ] One-line lesson (optional)
